const express = require('express');
const { google } = require('googleapis');
const admin = require('firebase-admin');
const serviceAccount = require('./gig-partner-3eb9f-firebase-adminsdk-6ac8d-9ff8c16396.json');

const app = express();
const PORT = process.env.PORT || 5000;

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const messaging = admin.messaging();

const SCOPES = [
  'https://www.googleapis.com/auth/cloud-platform',
  'https://www.googleapis.com/auth/firebase.messaging',
];

// Function to get access token
function getAccessToken() {
  return new Promise((resolve, reject) => {
    const key = require('./gig-partner-3eb9f-firebase-adminsdk-6ac8d-9ff8c16396.json');
    const jwtClient = new google.auth.JWT(
      key.client_email,
      null,
      key.private_key,
      SCOPES,
      null,
    );
    jwtClient.authorize((err, tokens) => {
      if (err) {
        reject(err);
        return;
      }
      resolve(tokens.access_token);
    });
  });
}

// List of FCM tokens
const tokens = [
  'cn3FVixpRYWuLI6hyEGwSb:APA91bFzGRPHgBP7jUHuQj8Yu5uIHSMtxEbqU657DO6bVxwGhAOnYpGGIzLXYF6f-dvg-PUQNiZJPJgwjVrkKdYqgx5vAPFUyuHg-jnqXa7lQ9_6RxJj8X9jzEizg8EY6TMBYycaWv9k',
  'c16OJ1D4R2umSG2hOUF5Jd:APA91bGYqzLZLwfJeBzbQs-1-3CY91fNG_TmV-FMKalo76eL7zbxQ2B_ugiL-Qs_P_lQ5AiheDLZ698IHFoerWxdYwA91Pklo5GG6XJjsozrQNcxlUS0LB0xz8YnqDMwwvplzJbqN06J',
  // Add more tokens here
];

// Function to send notification
async function sendNotification() {
  try {
    const accessToken = await getAccessToken();

    const message = {
      notification: {
        title: 'Breaking News',
        body: 'chek kar',
      },
      data: {
        key: 'msg',
      },
      tokens: tokens,
    };

    // Send multicast notification
    messaging
      .sendEachForMulticast(message)
      .then((response) => {
        console.log('Successfully sent message:', response);
      })
      .catch((error) => {
        console.log('Error sending message:', error);
      });

    console.log('Notification sent at:', new Date());
  } catch (err) {
    console.error('Error getting access token or sending message:', err);
  }
}

// Start the server
const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);

  // Choose the mode of notification
  const mode = process.env.NOTIFICATION_MODE || 'once';
  switch (mode) {
    case 'once':
      // Send notification once
      sendNotification();
      break;
    case 'repeat':
      // Schedule notification to be sent repeatedly
      const interval = process.env.NOTIFICATION_INTERVAL || '0 */6 * * *'; // Default: every 6 hours
      const cron = require('node-cron');
      cron.schedule(interval, sendNotification);
      break;
    case 'specific':
      const specificTime =
        process.env.NOTIFICATION_TIME || '2024-06-07T16:59:00'; // Default: 4:42 PM, June 7th, 2024
      const currentTime = new Date();
      const timeDifferenceMillis = Date.now() - currentTime.getTime(); // Calculate time difference between server and device
      const adjustedSpecificTime = new Date(
        new Date(specificTime).getTime() - timeDifferenceMillis,
      ); // Adjust specific time
      const delay = adjustedSpecificTime.getTime() - currentTime.getTime(); // Calculate delay
      if (delay > 0) {
        setTimeout(sendNotification, delay);
      }
      break;
    default:
      console.error('Invalid notification mode.');
  }
});
